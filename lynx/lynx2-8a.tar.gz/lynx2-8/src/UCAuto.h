
#ifndef UCAUTO_H
#define UCAUTO_H

extern void UCChangeTerminalCodepage PARAMS((int newcs, LYUCcharset *p));

#endif /* UCAUTO_H */
