
#ifndef LYMAINLOOP_H
#define LYMAINLOOP_H

extern int mainloop NOPARAMS;

#endif /* LYMAINLOOP_H */
